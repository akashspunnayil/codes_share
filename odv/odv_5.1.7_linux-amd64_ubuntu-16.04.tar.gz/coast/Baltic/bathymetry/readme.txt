Baltic Series: 

bathymetry based on: Kayser, B. and T. Seifert, Bathymetry of the
                     Baltic Sea, Baltic Sea Research Institute,
                     Warnemuende, 1995.

