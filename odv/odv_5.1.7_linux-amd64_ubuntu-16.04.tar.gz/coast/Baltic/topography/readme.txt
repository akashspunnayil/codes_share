Baltic Series: 

land topography based on: 5'x5' ETOPO5, segments with less than 11 vertices deleted.
