GlobHR Series: based on ETOPO5 topography  0.2x0.2 degree resolution.
               
