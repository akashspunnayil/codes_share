"GlobHR" overlays series.

Lakes, rivers, borders: CIA World Data Bank II subsampled +-0.1�/10pts. lakes with less
                        than 200 original points removed (note that rivers and borders may
                        be stroked but not filled; lakes may be stroked and filled)

SeaIce:                 monthly climatologies from Walsh (1978) and Zwally et
                        al. (1983); separate files for ice-covered area
                        fraction >20% and >50%.
