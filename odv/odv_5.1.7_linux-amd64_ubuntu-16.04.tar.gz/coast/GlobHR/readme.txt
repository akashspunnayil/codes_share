WIN32 GlobHR Series:  global

World.cdt: based on ETOPO2 2'x2' topography
           segments with less than 8 nodes deleted;
           accuracy decreased to 0.04�.

World_SIO.cdt: SIO shorelines.

