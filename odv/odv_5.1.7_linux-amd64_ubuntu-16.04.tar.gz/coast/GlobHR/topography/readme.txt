GlobHR Series: 
               land topography based on 5'x5' ETOPO5, segments with less than 11 vertices deleted,
               then resolution decrease with .2� tolerance using segm-length 10, then segments with
               less than 6 points deleted.
