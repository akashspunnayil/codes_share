MeditHR Series: 

bathymetry based on: Smith, W. H. F. and D. T. Sandwell, Global
                     Seafloor Topography from Satellite Altimetry and
                     Ship Depth Soundings, Science, v. 277,
                     p. 1956-1962, 26 September, 1997. [2'x2' degree
                     resolution].

