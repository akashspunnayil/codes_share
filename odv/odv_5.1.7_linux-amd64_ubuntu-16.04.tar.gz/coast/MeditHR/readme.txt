MeditHR Series: 

Download size:         4 MB
Required disk space:   6 MB

shoreline based on:  Wessel, P., and W. H. F. Smith, 1996,
                     A global self-consistent, hierarchical,
                     high-resolution shoreline database, J. Geophys.
                     Res., 101, 8741-8743.
