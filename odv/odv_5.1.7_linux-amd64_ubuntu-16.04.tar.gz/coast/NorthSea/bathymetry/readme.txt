NorthSea-GEBCO1 Series: 5W-12E / 47.4N-63N

bathymetry based on: GEBCO 1 minute dataset ('The GEBCO Digital Atlas
                     published by the British Oceanographic Data Centre
                     on behalf of IOC and IHO, 2003').

