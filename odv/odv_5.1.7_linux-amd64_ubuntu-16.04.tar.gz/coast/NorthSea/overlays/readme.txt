Lakes, rivers, borders: CIA World Data Bank II (note that rivers and
                        borders may be stroked but not filled; lakes
                        may be stroked and filled)
