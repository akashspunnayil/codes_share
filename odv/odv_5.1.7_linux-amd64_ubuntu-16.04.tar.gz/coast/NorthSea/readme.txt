NorthSea-GEBCO1 Series: 5W-12E / 47.4N-63N

shoreline based on: Wessel, P., and W. H. F. Smith, 1996, A global
                    self-consistent, hierarchical, high-resolution
                    shoreline database, J. Geophys.  Res., 101,
                    8741-8743.
