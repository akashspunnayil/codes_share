The MapView collection is empty and meant to be used for the
production of maps with or without station locations. It comes with
several view files for full-screen, high-resolution maps of the global
ocean as well as several regional sub-domains. 

You can also use the MapView collection with the ODV Gazetteer
feature. Start ODV with the MapView collection and switch on the
Gazetteer option using the Extras->Gazetteer option of the map popup
menu (alternatively, press Ctrl-G while the mouse is over the
map). Make sure to check the "Show Gazetteer Features" box. 

You can switch to a variety of pre-defined sub-domains by loading the
respective view file (View->Load View) or you may zoom into any region
of interest using one of the ODV zoom options.

