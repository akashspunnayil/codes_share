Outlines of Southern Ocean fronts from Orsi, 1995 in ODV graphics
object .gob format.

Nov/25/2014: More accurate versions from Oliver Esper, AWI.

Reiner Schlitzer (AWI)
