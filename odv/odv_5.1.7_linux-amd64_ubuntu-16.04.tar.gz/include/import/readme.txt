File "sdn_import_settings.xml" contains default "BODC parameter code
-> parameter label" and "BODC parameter code -> collection properties"
associations used by the SDN Spreadsheet importer.

The user may maintain a file "sdn_import_settings.xml" in the
ODV/import/ user directory containing additional or preferred
associations for codes already defined in the default substitution
file. In cases of conflict the user substitutions prevail.
