this directory contains ODV temporary files. do not delete files while 
odv is running.